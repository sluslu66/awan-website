function showCloud() {
    alert("Awan itu seperti mimpi—selalu berubah dan indah ☁️");
}
