# ☁️ Awan Website

Website sederhana bertema awan dengan animasi CSS.

## Fitur
- Animasi awan bergerak
- Desain langit biru
- Interaksi tombol JavaScript

## Cara Menjalankan
Buka file `index.html` di browser.

## Upload ke GitHub
1. Extract zip
2. Upload ke repository baru
3. Commit 🚀
